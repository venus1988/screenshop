﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Mobile Social Plugin - Other")]
	public class MSP_OpenAppInStore : FsmStateAction {

		public FsmString appPackageName;

		public override void OnEnter() {

			switch(Application.platform) {
				
			case RuntimePlatform.IPhonePlayer:
				//TODO: Add open app in store for iOS
				break;
			case RuntimePlatform.Android:
				AndroidNative.OpenAppInStore (appPackageName.Value);
				break;
			default: break;
			}

			Finish ();
		}
	}
}
