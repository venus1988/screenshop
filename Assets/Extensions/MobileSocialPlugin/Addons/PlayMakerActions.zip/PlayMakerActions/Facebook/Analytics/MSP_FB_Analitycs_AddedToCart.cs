﻿using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_Analitycs_AddedToCart : FsmStateAction {


		public FsmFloat  price;
		public FsmString id;
		public FsmString type;
		public FsmString currency;


		public FsmBool IsPaymentInfoAvaliable;


		public override void OnEnter() {
			//The user has entered their payment info.
			SPFacebookAnalytics.AddedToCart (price.Value, id.Value, type.Value, currency.Value);
			Finish ();
		}

		public override void Reset() {
			base.Reset();
			currency.Value =  "USD";
		}
		
	}
}