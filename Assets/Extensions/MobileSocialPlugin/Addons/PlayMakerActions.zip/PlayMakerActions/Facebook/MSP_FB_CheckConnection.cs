﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_CheckConnection : FsmStateAction {
		
		public FsmBool connection;
		
		public FsmEvent fbConnected;
		public FsmEvent fbDisconnected;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			connection.Value = SPFacebook.instance.IsLoggedIn || IsInEdditorMode ? true : false;								
			
			Fsm.Event (connection.Value ? fbConnected : fbDisconnected);
			
			Finish ();
		}
	}
}