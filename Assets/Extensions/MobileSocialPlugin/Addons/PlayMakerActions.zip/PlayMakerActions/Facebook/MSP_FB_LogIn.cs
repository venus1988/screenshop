using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Facebook")]
	public class MSP_FB_LogIn : FsmStateAction {


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {


			if(SPFacebook.instance.IsLoggedIn) {
				OnSuccess();
				return;
			}


			if(SPFacebook.instance.IsInited) {
				OnInitCompleteAction();
			} else {
				Debug.Log("SPFacebook.instance.Init");
				SPFacebook.instance.OnInitCompleteAction += OnInitCompleteAction;
				SPFacebook.instance.Init();

			}




		}

		private void OnInitCompleteAction () {
			Debug.Log("OnInitCompleteAction");
			if(SPFacebook.instance.IsLoggedIn) {
				OnSuccess();
			} else {
				Debug.Log("OnInitCompleteAction");
				SPFacebook.instance.OnAuthCompleteAction += OnAuthCompleteAction;
				SPFacebook.instance.Login();
			}



		}

		private void OnAuthCompleteAction (FBResult obj) {
			SPFacebook.instance.OnAuthCompleteAction -= OnAuthCompleteAction;
			if(SPFacebook.instance.IsLoggedIn) {
				OnSuccess();
			} else {
				OnFail();
			}
		}

	

		private void OnFail() {
			Fsm.Event(failEvent);
			Finish();
		}
		
		private void OnSuccess() {
			Fsm.Event(successEvent);
			Finish();
		}

	}
}


