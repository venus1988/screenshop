using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			SPTwitter.instance.addEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			SPTwitter.instance.addEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
			
			SPTwitter.instance.Post(message.Value, texture.Value as Texture2D);
			
		}

		private void RemoveListeners() {
			SPTwitter.instance.removeEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			SPTwitter.instance.removeEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
		}
		
		
		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListeners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListeners();
			Finish();
		}
		
	}
}



