using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterLogIn : FsmStateAction {

 
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(SPTwitter.instance.IsAuthed) {
				OnSuccess();
				return;
			}

			SPTwitter.instance.Init();

			SPTwitter.instance.addEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccess);
			SPTwitter.instance.addEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);

			SPTwitter.instance.AuthenticateUser();
		}

		private void RemoveListners() {
			SPTwitter.instance.removeEventListener(TwitterEvents.AUTHENTICATION_SUCCEEDED,  OnSuccess);
			SPTwitter.instance.removeEventListener(TwitterEvents.AUTHENTICATION_FAILED,  	OnFail);
		}

		private void OnFail() {
			Fsm.Event(failEvent);
			RemoveListners();
			Finish();
		}
		
		private void OnSuccess() {

			if(!SPTwitter.instance.IsAuthed) {
				OnFail();
				return;
			}

			Fsm.Event(successEvent);
			RemoveListners();
			Finish();
		}

	}
}


