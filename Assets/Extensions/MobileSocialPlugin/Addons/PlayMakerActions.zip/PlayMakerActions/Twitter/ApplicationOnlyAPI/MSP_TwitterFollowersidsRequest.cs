﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterFollowersidsRequest : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public FsmString user_id;
		public FsmString[] ids;
		
		public override void OnEnter() {	
			TW_FollowersIdsRequest r =  TW_FollowersIdsRequest.Create();
			r.addEventListener(BaseEvent.COMPLETE, OnIdsLoaded);
			if (user_id.Value.Length > 0) {
				r.AddParam ("user_id", user_id.Value);
			}
			r.Send();
		}
		
		private void OnIdsLoaded(CEvent e) {
			TW_APIRequstResult result = e.data as TW_APIRequstResult;			
			
			if(result.IsSucceeded) {
				ids = new FsmString[result.ids.Count];
				
				for(int i = 0; i < result.ids.Count; i++) {
					ids[i].Value = result.ids[i];
				}
				
				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
