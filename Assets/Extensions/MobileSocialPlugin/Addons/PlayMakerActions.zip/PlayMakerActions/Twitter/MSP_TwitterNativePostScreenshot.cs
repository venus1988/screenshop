using UnityEngine;
using UnionAssets.FLE;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Twitter")]
	public class MSP_TwitterNativePostScreenshot : FsmStateAction {

		public FsmString message;


		public override void OnEnter() {

			TwitterPostScreenshotTask post = 	TwitterPostScreenshotTask.Create();
			post.addEventListener(BaseEvent.COMPLETE, OnComplete);
			post.Post(message.Value);


		}

		private void OnComplete(CEvent e) {
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, OnComplete);
			Finish();
		}




	}
}


