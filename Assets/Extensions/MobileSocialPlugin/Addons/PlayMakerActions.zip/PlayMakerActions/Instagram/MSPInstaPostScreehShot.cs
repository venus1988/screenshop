using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Social Plugin - Other")]
	public class MSPInstaPostScreehShot : FsmStateAction {
	
		public FsmString message;
		public FsmTexture texture;

		public FsmEvent successEvent;
		public FsmEvent failEvent;
		public FsmEvent appNotInstalledEvent;

		private InstagramPostScreenshotTask post;
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			post = 	InstagramPostScreenshotTask.Create();
			post.OnPostScreenshotCompleteAction += OnComplete;
			post.Post(message.Value);			
		}
		
		private void OnComplete(InstagramPostResult res) {
			post.OnPostScreenshotCompleteAction -= OnComplete;
			if (res == InstagramPostResult.RESULT_OK) {
				Fsm.Event (successEvent);
			} else if (res == InstagramPostResult.NO_APPLICATION_INSTALLED) {
				Fsm.Event(appNotInstalledEvent);
			}else {
				Fsm.Event(failEvent);
			}
			Finish();
		}
	}
}



